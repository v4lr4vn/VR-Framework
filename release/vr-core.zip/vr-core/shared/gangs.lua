VRCore.Shared.Gangs = {
    none = { label = 'No Gang', grades = { ['0'] = { name = 'Unaffiliated' } } },

    lostmc = {
        label = 'The Lost MC',
        grades = {
            ['0'] = { name = 'Recruit' },
            ['1'] = { name = 'Enforcer' },
            ['2'] = { name = 'Shot Caller' },
            ['3'] = { name = 'Boss', isboss = true },
        },
    },
}
