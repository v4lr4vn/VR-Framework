local function typeof(var)
	local _type = type(var)
	if _type ~= "table" and _type ~= "userdata" then
		return _type
	end
	local _meta = getmetatable(var)
	if _meta ~= nil and _meta._NAME ~= nil then
		return _meta._NAME
	else
		return _type
	end
end

function LoadJobOutfit(oData)
	local ped = cache.ped

	local data = oData.outfitData

	if typeof(data) ~= "table" then
		data = json.decode(data)
	end

	if data["pants"] ~= nil then
		SetPedComponentVariation(ped, 4, data["pants"].item, data["pants"].texture, 0)
	end

	if data["arms"] ~= nil then
		SetPedComponentVariation(ped, 3, data["arms"].item, data["arms"].texture, 0)
	end

	if data["t-shirt"] ~= nil then
		SetPedComponentVariation(ped, 8, data["t-shirt"].item, data["t-shirt"].texture, 0)
	end

	if data["vest"] ~= nil then
		SetPedComponentVariation(ped, 9, data["vest"].item, data["vest"].texture, 0)
	end

	if data["torso2"] ~= nil then
		SetPedComponentVariation(ped, 11, data["torso2"].item, data["torso2"].texture, 0)
	end

	if data["shoes"] ~= nil then
		SetPedComponentVariation(ped, 6, data["shoes"].item, data["shoes"].texture, 0)
	end

	if data["decals"] ~= nil then
		SetPedComponentVariation(ped, 10, data["decals"].item, data["decals"].texture, 0)
	end

	local tracker = Config.TrackerClothingOptions

	if data["accessory"] ~= nil then
		if Framework.HasTracker() then
			SetPedComponentVariation(ped, 7, tracker.drawable, tracker.texture, 0)
		else
			SetPedComponentVariation(ped, 7, data["accessory"].item, data["accessory"].texture, 0)
		end
	else
		if Framework.HasTracker() then
			SetPedComponentVariation(ped, 7, tracker.drawable, tracker.texture, 0)
		else
			local drawableId = GetPedDrawableVariation(ped, 7)

			if drawableId ~= -1 then
				local textureId = GetPedTextureVariation(ped, 7)
				if drawableId == tracker.drawable and textureId == tracker.texture then
					SetPedComponentVariation(ped, 7, -1, 0, 2)
				end
			end
		end
	end

	if data["mask"] ~= nil then
		SetPedComponentVariation(ped, 1, data["mask"].item, data["mask"].texture, 0)
	end

	if data["bag"] ~= nil then
		SetPedComponentVariation(ped, 5, data["bag"].item, data["bag"].texture, 0)
	end

	if data["hat"] ~= nil then
		if data["hat"].item ~= -1 and data["hat"].item ~= 0 then
			SetPedPropIndex(ped, 0, data["hat"].item, data["hat"].texture, true)
		else
			ClearPedProp(ped, 0)
		end
	end

	if data["glass"] ~= nil then
		if data["glass"].item ~= -1 and data["glass"].item ~= 0 then
			SetPedPropIndex(ped, 1, data["glass"].item, data["glass"].texture, true)
		else
			ClearPedProp(ped, 1)
		end
	end

	if data["ear"] ~= nil then
		if data["ear"].item ~= -1 and data["ear"].item ~= 0 then
			SetPedPropIndex(ped, 2, data["ear"].item, data["ear"].texture, true)
		else
			ClearPedProp(ped, 2)
		end
	end

	local length = 0
	for _ in pairs(data) do
		length = length + 1
	end

	if Config.PersistUniforms and length > 1 then
		TriggerServerEvent("vr-clothing:server:syncUniform", {
			jobName = oData.jobName,
			gender = oData.gender,
			label = oData.name,
		})
	end
end

RegisterNetEvent("vr-clothing:client:loadJobOutfit", LoadJobOutfit)

RegisterNetEvent("vr-clothing:client:openOutfitMenu", function()
	OpenMenu(nil, "outfit")
end)

RegisterNetEvent("vr-clothing:client:outfitsCommand", function(isJob)
	local outfits = GetPlayerJobOutfits(isJob)
	TriggerEvent("vr-clothing:client:openJobOutfitsMenu", outfits)
end)
